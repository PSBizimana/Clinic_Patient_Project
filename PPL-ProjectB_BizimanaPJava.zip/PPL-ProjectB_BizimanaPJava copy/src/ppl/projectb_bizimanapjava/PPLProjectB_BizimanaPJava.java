/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppl.projectb_bizimanapjava;

/**
 *
 * @author Prince
 */

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PPLProjectB_BizimanaPJava {

    static ArrayList<ClinicQueue> QueueArray = new ArrayList();
    static ArrayList<ClinicQueue> available = new ArrayList();
    static String InputString;
    static String DoctorList;
    
    public static void main(String[] args) {

        Initialize();//initializes physician queues and stores them in the QueueArray
        
        //string to prompt user with options
        final String PromptString = "0. Exit\n1. Display Available Physicians\n2. Patient Check-in\n3. Patient Check-out\n4. "
                + "Reassign a Patient\n5. Display a Physician's Queue\n";
        Boolean ExitTime = false;
        int Option;
     
        while(!ExitTime)
        {   
            InputString = JOptionPane.showInputDialog(null, PromptString, "Clinic Monitor", JOptionPane.QUESTION_MESSAGE); 
            Option = Integer.parseInt(InputString);
            
            switch(Option)
            {
                case 0: {ExitTime = true; break;}
                case 1: {DisplayAvailablePhysicians(); break;}
                case 2: {EnqueuePatient(); break;}
                case 3: {DequeuePatient(); break;}
                case 4: {ReassignPatient(); break;}
                case 5: {DisplayQueue(); break;}
            }
        }
    }
   
    public static void Initialize()
    {
        //instantiate variables and default the doctorlist to an empty string. 
        int x, num;
        String name;
        boolean status;
        ClinicQueue inQueue;
        DoctorList = "";
        
        //prompt for and read in how many Physicians are working 
        InputString = JOptionPane.showInputDialog(null, "How many Physicians are being added?", "Determining Available Physicians", JOptionPane.QUESTION_MESSAGE);
        num = Integer.parseInt(InputString);
        //asks for data on each physicians to make a queue for each
        for(x = 0; x < num; x++)
        {
            //prompts for and reads in the physician's name
            InputString = JOptionPane.showInputDialog(null, "What is the Physician's name?", "Physician Number " + (x + 1), JOptionPane.QUESTION_MESSAGE);
            name = InputString;
            DoctorList += x + ": " + name + "\n";
            //prompts for and reads in the physician's queue status
            InputString = JOptionPane.showInputDialog(null, "Is " + name + " taking patients at the moment?(y/n)", "Finding Physician Status", JOptionPane.QUESTION_MESSAGE);
            //declares boolean value based on user read in
            if(InputString.equals("y"))
            {
                status = true;
                inQueue = new ClinicQueue(name, status);//intantiates new queue and stores it in the ArrayList
                available.add(available.size(), inQueue);
            }
            else
            {
            status = false;
            //intantiates new queue and stores it in the ArrayList
            inQueue = new ClinicQueue(name, status);
            }
            
            QueueArray.add(x, inQueue);

        }
    }
   
    //Outputs a list of available physicians to the user
    public static void DisplayAvailablePhysicians()
    {
        //instantiate variables and default the Availablestring to "Available Physicians:\n"
        int x, y;
        ClinicQueue inQueue;
        String AvailableString = "Available Physicians:\n";
        
        //loops to add available queues to the available ArrayList
        for(x = 0, y=0; x < QueueArray.size(); x++)
        {
            if(QueueArray.get(x).Status)//if the queue status is true
            {
                AvailableString += QueueArray.get(x).Physician + "\n";
                inQueue = QueueArray.get(x);//store queue in inQueue
                available.add(y, inQueue);//store inQueue in available
                y++;//inclements index of available
            }
        }
        //display the list of available Physicians
        JOptionPane.showInputDialog(null, AvailableString, "Available Physicians", JOptionPane.QUESTION_MESSAGE);
    }

    //Add patient to a specifically desired queue 
    public static void EnqueuePatient()
    {
        //instantiate variables 
        boolean exit = false;
        
        while(!exit)
        {
            //prompt for which Physician they are here to see
            InputString = JOptionPane.showInputDialog(null, "Which Physician are you here to see?\n\n" + DoctorList, "Patient Check-in", JOptionPane.QUESTION_MESSAGE);
            int index = Integer.parseInt(InputString);
            ClinicPatient patient = new ClinicPatient();
            //if the doctor's queue is open continue to data input
            if(QueueArray.get(index).Status)
            {
                exit = true;//allows you to exit while loop after adding getting patient data
                patient.InputData();//prompts for and stores patient data
                QueueArray.get(index).Enqueue(patient);//adds patient to the queue
            }
            //if doctor's queue is closed
            else
            {
                //prompt that the doctor is not seeing patients, then ask if they will choose another doctor or cancel checking in
                InputString = JOptionPane.showInputDialog(null, "That Physician is not seeing patients at this time." + 
                        "\n\nYou can:\n1. Choose a different physician\n2. Cancel check-in", "Patient Check-in", JOptionPane.QUESTION_MESSAGE);
                int option = Integer.parseInt(InputString);
                //if user chose cancel check-in break from while loop, otherwise loop back to choose another doctor
                if(option == 2)
                    break;      
            }
        }
    }
    
    //remove patient f rom queue
    public static void DequeuePatient()
    {           
        //prompt for which queue to be dequeued and read in
        InputString = JOptionPane.showInputDialog(null, "Which physician did you just see?\n\n" + DoctorList, "Patient Check-out", JOptionPane.QUESTION_MESSAGE);
        int index = Integer.parseInt(InputString);//parse string to int and store in index
        QueueArray.get(index).Dequeue();//dequeues the selected queue
    }
    
    //move patient to another queue
    public static void ReassignPatient()
    {
         //instantiate variables 
        int x, y, index;
        boolean exit = false;
        //create a temporary array to hold info while it is being moved
        ClinicPatient[] temp;
        ClinicPatient MovedPatient = new ClinicPatient();
        String name, prompt = "Choose a non-empty Queue to take from:\n\n";
        
        //adds non-empty queues to prompt string
        for(x = 0; x < available.size(); x++)
        {
            if(available.get(x).Length > 0)
            prompt += x + ": " + available.get(x).Physician + "\n";
        }
        
        //prompts for a a queue to take from and stores in index
        index = Integer.parseInt(JOptionPane.showInputDialog(null,  prompt, "Reassign Patient", JOptionPane.QUESTION_MESSAGE));
        name = available.get(index).Physician;
        //finds queue, lists patients inside, and prompts for one to move
        for(x = 0; !exit; x++)
        {
            if(available.get(x).Physician.equals(name))
            {
                temp = available.get(x).toArray();
                prompt = "Choose a patient to move:\n\n";
                //appends prompts with patient names
                for(y = 0; y < temp.length; y++)
                {
                    prompt += y + ": " + temp[y].Name + "\n";
                }
                //prompts which patient is being reassigned
                InputString = JOptionPane.showInputDialog(null,  prompt, "Reassign Patient", JOptionPane.QUESTION_MESSAGE);
                index = Integer.parseInt(InputString);
                MovedPatient =  available.get(x).GetAndMove(temp[index].Name);//take patron from queue and stores it
                exit = true;
            } 
        }
        //prompts for a queue to move it to
        prompt = "To whom do we assign the patient to?\n\n";
        for(x = 0; x < available.size(); x++)
        {
            prompt += x + ": " +available.get(x).Physician + "\n";
        }
        
        InputString = JOptionPane.showInputDialog(null,  prompt, "Reassign Patient", JOptionPane.QUESTION_MESSAGE);
        index = Integer.parseInt(InputString);
        available.get(index).Enqueue(MovedPatient);
        
    }
    
    //Displays a queue
    public static void DisplayQueue()
    {
        int index;//instance data
        
        //prompts for and reads in Queue to display
        InputString = JOptionPane.showInputDialog(null, "Who's Queue would you like to display?\n\n" + DoctorList, "DisplayQueue", JOptionPane.QUESTION_MESSAGE);
        index = Integer.parseInt(InputString);
        
        //displays queue
        JOptionPane.showInputDialog(null, QueueArray.get(index).toString(), "DisplayQueue", JOptionPane.QUESTION_MESSAGE);
    }
}