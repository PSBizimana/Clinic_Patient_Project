/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppl.projectb_bizimanapjava;

/**
 *
 * @author Prince
 */
public class ClinicQueue {

    //instantiate the variables
    protected String Physician;
    protected ClinicNode First, Last;
    protected int Length;
    protected boolean Status;//determines if queue is open or closed
    
    //Constructor that takes in an instance of a patient and their avalibality status
        public ClinicQueue(String inPhysician, boolean inStatus)
    {
        Physician = inPhysician;
        First = null;//creates head and rear nodes set to null
        Last = null;
        Length = 0;//sets size of the list to 0
        Status = inStatus;//sets queue to open
    }
    //clear the queue
    public void Clear()
    {
        First = null;
        Last = null;
        Length = 0;
    }   
    //enqueue adds node to the end of the queue
    public void Enqueue(ClinicPatient element)
    {
        //two new nodes, one with the perameter patient, and the onther null
        ClinicNode Node = new ClinicNode(element);
        ClinicNode Current;
        
        if(Length == 0)//if queue is empty 
        {
            First = Last = Node;//if queue is empty First and Last node is the patient
            Length++;
        }  
        else //if queue is not empty
        {
            Current = Last;
            Current.Next = Node;
            Last = Node;
            Length++;
        }
    }
    //takes the first patient off the queue
    public void Dequeue()
    {        
        if(Length != 0)
        {
            First = First.Next;
            Length--;
        }
    }
    //This searches throught the queue to find  the correct patients related to their doctor
    public void SearchAndModify(String inName, ClinicPatient inPatient)
    {
        //makes current node, next node, and temp patient
        ClinicNode Current = First;
        ClinicNode Next = Current.Next;
        boolean exit = false;
        
        //checks first node
        if(Current.Data.Name.equals(inName))
        {
            Current.Data.Modify(inPatient);
        }
        else//checks the rest of the queue
        {
            while(!exit)
            {
                if(Next.Data.Name.equals(inName))//if the next node matches the one were looking for
                {
                    Next.Data.Modify(inPatient);
                    exit = true;//allows us to exit the while loop
                }
                else//cycles through the queue
                {
                    Current = Next;
                    Next = Next.Next;
                }
            }
        }

    }
    public ClinicPatient GetAndMove(String inName)
    {
        //instance data
        ClinicPatient output;
        ClinicNode Current = First;
        ClinicNode Next = Current.Next;
        
        //check first node
        if(Current.Data.Name.equals(inName))
        {
            output = Current.Data;
            Dequeue();
        }   
        else//check the rest of the list
        {
            while(!Next.Data.Name.equals(inName))
            {
                Current = Next;//increments the current and next nodes
                Next = Next.Next;
            }
            output = Next.Data;//sets output
            Current.Next = Next.Next;//cuts out Next node
        }
        
        return output;
    }
    //toArray returns an array with the queue data inside
    public ClinicPatient[] toArray()
    {
        ClinicPatient[] array = new ClinicPatient[Length];//instantiates an array of patients
        ClinicNode Current = First;
        for(int index = 0; index < Length; index++)
        {
            array[index] = Current.Data;
            Current = Current.Next;
        }
        return array;
    }  
    //This function outputs data
    public String toString()
    {
        ClinicNode Current = First;
        String result = "Physician: " + Physician + "\nStatus: ";
                
        if(Status)
            result += "Available";
        else 
            result += "Unavailable";
                
        result += "\n\nPatients:\n";
        
        if(Current == null)
        {
            result = "Queue is empty.";
        }
        else
        {
            while(Current != null)
            {
                result += Current.toString();
                Current = Current.Next;
            }
        }
        
        return result;
    }
}