/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppl.projectb_bizimanapjava;

/**
 *
 * @author Prince
 */
public class ClinicNode {
    
    //instantiate the variables
    protected ClinicPatient Data;
    protected ClinicNode Next;
    
    //Constructor that takes in an instant of a patient 
    public ClinicNode(ClinicPatient inPatient)
    {
        Data = inPatient;
        Next = null;
    }
    
    //This function outputs data
    public String toString()
    {
        String result;
        
        result = Data.toString();
        
        return result;
    }
}
