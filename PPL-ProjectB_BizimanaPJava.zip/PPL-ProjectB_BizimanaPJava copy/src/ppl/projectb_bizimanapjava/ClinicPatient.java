/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppl.projectb_bizimanapjava;

/**
 *
 * @author Prince
 */
import javax.swing.JOptionPane;
public class ClinicPatient {   
    //insantiate protected vairables
    
    protected String Name;
    protected int IDNum;
    protected long PhoneNum;
   //default constructor for the cliicpatient class
   public ClinicPatient()
           {
               
               //give default values to variables
               Name = "";
               IDNum = 0;
               PhoneNum = 0;
           }
   
   //prompts for and stores data in an object
   public void InputData()
   {
       String inputName, inPhoneNum, inIDNum;
       
       //prompts for patient's name and stores in inputName
       inputName = JOptionPane.showInputDialog(null, "Enter patient's name.", "Patient Check-in", JOptionPane.QUESTION_MESSAGE);
       Name = inputName; 
        //stores read in name to patient name
       
       //prompts for patient ID number and stores in inIDNum
       inIDNum = JOptionPane.showInputDialog(null, "Enter patient's ID number. \nNumbers only(no punctuation or extra characters)", "Patient Check-in", JOptionPane.QUESTION_MESSAGE);
       IDNum = Integer.parseInt(inIDNum);
        //parses inIDNum to integer and stores in patient IDNum
       
       //prompts for patient phone number and stores in inPhoneNum
       inPhoneNum = JOptionPane.showInputDialog(null, "Enter patient's phone number.\nNumbers only(no punctuation or extra characters)", "Patient Check-in", JOptionPane.QUESTION_MESSAGE);
       PhoneNum = Long.parseLong(inPhoneNum); 
        //parses inPhoneNum to integer and stores in PhoneNum
   }
   
   //This function is to modify any given patient when called
   public void Modify(ClinicPatient thisOne)
   {
       Name = thisOne.Name;
       PhoneNum = thisOne.PhoneNum;
       IDNum = thisOne.IDNum;
   }
   
   //This function outputs data
   public String toString()
   {
       String result;
       
       result = "Name: " + Name + "\nID Number: " + IDNum + "\nPhone #: " + PhoneNum + "\n\n";
       
       return result;
   }
}